package component.noahzu.github.io.uicomponent.uicompont.page;

import component.noahzu.github.io.uicomponent.core.IPage;

/**
 * Created by zujinhao on 2018/1/2.
 */

public class CommonPage implements IPage {
}
