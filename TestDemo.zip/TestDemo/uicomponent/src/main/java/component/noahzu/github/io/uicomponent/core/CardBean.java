package component.noahzu.github.io.uicomponent.core;

/**
 * Created by zujinhao on 2018/1/2.
 */

public class CardBean {
}
