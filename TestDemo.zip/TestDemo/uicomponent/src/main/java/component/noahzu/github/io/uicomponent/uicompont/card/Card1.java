package component.noahzu.github.io.uicomponent.uicompont.card;

import android.content.Context;
import android.widget.RelativeLayout;

import component.noahzu.github.io.uicomponent.core.ICard;

/**
 * Created by zujinhao on 2018/1/3.
 */

public class Card1 extends RelativeLayout implements ICard {

    public Card1(Context context) {
        super(context);
    }
}
