package component.noahzu.github.io.uicomponent.uicompont.card;

import component.noahzu.github.io.uicomponent.core.ICard;

/**
 * Created by zujinhao on 2018/1/2.
 */

public class LiveCard implements ICard {
}
