package component.noahzu.github.io.uirouter;

import android.content.Context;
import android.os.Bundle;

import java.lang.ref.WeakReference;

/**
 * Created by zujinhao on 2018/1/24.
 */

public class UIRouterSpec {
    String url;
    Bundle bundle;
    int requestCode;
}
