package com.example.zujinhao.test.widget;

import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

public class MyViewHolder extends RecyclerView.ViewHolder{

        public MyViewHolder(View itemView) {
            super(itemView);
        }
}