package com.example.zujinhao.test.component;

import io.reactivex.subjects.Subject;

/**
 * Created by zujinhao on 2017/12/25.
 */

public class RxBus {
    private static volatile RxBus defaultInstance;

}
