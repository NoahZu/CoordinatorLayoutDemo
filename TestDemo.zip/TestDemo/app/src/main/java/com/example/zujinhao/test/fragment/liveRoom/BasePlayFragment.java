package com.example.zujinhao.test.fragment.liveRoom;

import androidx.fragment.app.Fragment;

/**
 * Created by zujinhao on 2017/9/5.
 */

public abstract class BasePlayFragment extends Fragment {


    public abstract void onReceiveMessage(String message);
}
